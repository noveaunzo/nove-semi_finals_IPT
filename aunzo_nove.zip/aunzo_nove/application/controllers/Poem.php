<?php  

defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * 
 */
class Poem extends CI_Controller
{

	function __construct(){
		parent:: __construct();
		$this->load->model('Aunzo','Nove');
		// $this->load->modal('Aunzo','p');
	}
	
	function index(){

		$data['tbl_data'] = $this->Nove->getdata();
		$this->load->view('nove/index', $data);
	}


	public function next_page(){
		$data['tbl_data'] = $this->Nove->getdata();
		$this->load->view('nove/poem',$data);
	}

	public function poem(){
		$data['tbl_data'] = $this->Nove->getdata();
		$this->load->view('nove/us' ,$data);
	}

	public function wall_poem(){
		$data['tbl_data'] = $this->Nove->getdata();
		$this->load->view('nove/wall' ,$data);
	}

	public function angel_poem(){
		$data['tbl_data'] = $this->Nove->getdata();
		$this->load->view('nove/angel' ,$data);
	}

	public function menu(){
		$data['tbl_data'] = $this->Nove->getdata();
		$this->load->view('nove/index', $data);
	}
}



?>