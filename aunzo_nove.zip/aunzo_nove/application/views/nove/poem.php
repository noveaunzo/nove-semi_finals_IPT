<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="wclassth=device-wclassth, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Nove Aunzo</title>
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Fjalla+One&display=swap" rel="stylesheet">
	<link rel="icon" type="image/jpg" href="<?php echo base_url('assets/image/bee.jpg') ?>" sizes="16x16">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css') ?>">
	<link href="https://fonts.googleapis.com/css2?family=Syne+Mono&display=swap" rel="stylesheet">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">

			<h4>ₛₐᵥₑ ₜₕₑ bₑₑₛ ₐₙd ₜₕₑ fᵢᵣₑfₗᵢₑₛ</h4>
			<?php  

				if ($tbl_data) {
					foreach ($tbl_data as $data) {
						?>
						<span>Author: <?php echo $data->fname . " ".$data->lname; ?></span>
					<?php	
					}
				}
			?>
		</div>
	</header>
	<!-- end of header -->

	<!-- home -->

		<div class="home">
			<img src="<?php echo base_url() ?>assets/svg/home-solid.svg" width="30" height="30" title="Home" onclick="home()";>
		</div>

	<!-- end of home -->

	<!-- btns -->
	<div class="box">
		<div class="layer">
			<ul>
				<li><button class="btn1" onclick="us();" title="Us">US</button></li>
				<li><button class="btn2" onclick="wall();" title="Wall Flower">WALLFLOWER</button></li>
			</ul>
		</div>
		<div class="layer2">
			<button class="btn3" onclick="angel()" title="No Angel">NO ANGEL</button>
		</div>
	</div>

	<!-- end of btns -->


	<script type="text/javascript">
		function us()
		{
			window.location.href="<?php echo base_url('Poem/poem'); ?>"
		}

		function wall(){
			window.location.href="<?php echo base_url('Poem/wall_poem'); ?>"
		}
		function angel(){
			window.location.href="<?php echo base_url('Poem/angel_poem'); ?>"
		}

		function home(){
			window.location.href="<?php echo base_url('Poem/menu') ?>";
		}
	</script>

	
	
</body>
</html>