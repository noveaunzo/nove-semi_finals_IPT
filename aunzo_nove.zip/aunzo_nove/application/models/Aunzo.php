<?php  

defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * 
 */
class Aunzo extends CI_Model
{
	
	public function getdata()
	{
		$table = $this->db->table_exists('buni');
		if ($table) {
			$query = $this->db->get('buni');
			if($query->num_rows() > 0){
				return $query->result();
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
}


?>